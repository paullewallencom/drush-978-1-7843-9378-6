#Test
----


The test directory is used for external test. This is great for [selenium](http://seleniumhq.org/) or [CasperJS](http://casperjs.org/) test.

There's two default directory. The selenium directory and the casperjs directory. Feel free to add or remove your own.

Note: This is not a directory for simpletest.
