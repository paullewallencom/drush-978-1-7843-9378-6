Any custom project-specific scripts can be placed here.

Any PHP scripts can be run by using the
`$ drush scr ../scripts.foo.php` command from within the docroot directory.
