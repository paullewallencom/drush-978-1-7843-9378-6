Sample Drupal 7 module used to play with database updates + features.
