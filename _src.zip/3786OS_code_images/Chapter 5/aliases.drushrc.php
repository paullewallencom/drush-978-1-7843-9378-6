<?php

/**
 * @file
 * User-wide site alias definitions.
 *
 * Site aliases defined here are available anywhere for the current user.
 */

// Sample Drupal project.
$aliases["example.local"] = array (
  'root' => '/home/juampy/projects/example',
  'uri' => 'example.local',
);
